import React from 'react'

const Configlist = () => {
  return (
    <div>Configlist</div>
  )
}

export default Configlist