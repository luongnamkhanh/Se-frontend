import React from 'react'

const Addconfig = () => {
  return (
    <div>Addconfig</div>
  )
}

export default Addconfig